<?php

namespace App\Http\Controllers\Internal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Validator;
use DB;
use App\Models\Type_course;
use App\Models\Course;

class CoursesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $courses = Course::all();

        if($courses){
            return response()->json($courses, 200);
        }
        return response()->json(['message' => 'Courses not found!'], 404);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $type_courses = Type_course::all();

        if($type_courses){
            return response()->json($type_courses, 200);
        }
        return response()->json(['message' => 'Type courses not found!'], 404);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'title' => 'required|unique:courses,title,NULL,id,deleted_at,NULL',
			'description' => 'required',
			'cover' => 'required',
			'price' => 'required|numeric',
			'video' => 'required',
			'type_course_id' => 'required|numeric'
        ]);
        if($validator->fails()){
            return response()->json([
                'error' => $validator->messages()], 404);
        }else{
        	$title = $request->input('title');
			$description = $request->input('description');
			$cover = $request->input('cover');
			$price = $request->input('price');
			$video = $request->input('video');
			$published = $request->input('published');
			$type_course_id = $request->input('type_course_id');

            $course = new Course;
            $course->title = $title;
			$course->description = $description;
			$course->slug = str_slug($title, '-');
			$course->cover = $cover;
			$course->price = $price;
			$course->video = $video;
			$course->published = $published;
			$course->type_course_id = $type_course_id;

            if($course->save()){
                return response()->json(['message' => 'Successfully created course!'], 200);
            }
            return response()->json(['message' => 'Course was not created!'], 404);

        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $course = Course::with('type_courses')->where('id', $id)->first();
        
        if($course){
        	return response()->json($course, 200);
        }
        return response()->json(['message' => 'Course not found!'], 404);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $course = Course::with('type_courses')->where('id', $id)->first();
        $type_courses = Type_course::all();

        if($course){
            return response()->json(['course' => $course, 'type_courses' => $type_courses], 200);
        }
        return response()->json(['message' => 'Course not found!'], 404);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'title' => 'required|unique:courses,title,'.$id.',id,deleted_at,NULL',
			'description' => 'required',
			'cover' => 'required',
			'price' => 'required|numeric',
			'video' => 'required',
			'type_course_id' => 'required|numeric'
        ]);
        if($validator->fails()){
            return response()->json([
                'error' => $validator->messages()], 404);
        }else{

            $title = $request->input('title');
			$description = $request->input('description');
			$cover = $request->input('cover');
			$price = $request->input('price');
			$video = $request->input('video');
			$published = $request->input('published');
			$type_course_id = $request->input('type_course_id');

			$course = Course::find($id);
            $course->title = $title;
			$course->description = $description;
			$course->slug = str_slug($title, '-');
			$course->cover = $cover;
			$course->price = $price;
			$course->video = $video;
			$course->published = $published;
			$course->type_course_id = $type_course_id;

            if($course->save()){
                return response()->json(['message' => 'Successfully updated Course!'], 200);
            }
            return response()->json(['message' => 'Course was not updated!'], 404);

        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $course = Course::find($id);

        if($course->delete()){
            return response()->json(['message' => 'Successfully deleted Course!'], 200);
        }
        return response()->json(['error' => 'Course was not deleted!'], 404);
    }
}
