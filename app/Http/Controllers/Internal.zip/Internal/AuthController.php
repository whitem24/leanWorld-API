<?php
namespace App\Http\Controllers\Internal;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Auth;
use Validator;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        $request->validate([
            'name' => 'required', 
            'email' => 'required|email', 
            'password' => 'required|min:6'
        ]);


        $user = User::create([
            'name' => $request->name, 
            'email' => $request->email, 
            'password' => bcrypt($request->password)
        ]);

        return response()->json($user);
    }
    public function login(Request $request)
    {
       /*  $request->validate([
            'email' => 'required|email|exists:users,email', 
            'password' => 'required'
        ]); */
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users,email', 
            'password' => 'required'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'error' => $validator->messages()], 404);   
        }

        if( Auth::attempt(['email'=>$request->email, 'password'=>$request->password]) ) {
            $user = Auth::user();

            $token = $user->createToken($user->email.'-'.now());

            return response()->json([
                'token' => $token->accessToken
            ]);
        }else{
            return response()->json([
                'error_mismatch' => 'Invalid E-mail or password.'
            ], 404);
        }
    }

    
}
