<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Carbon\Carbon;
use DB;

class MenusTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('menus')->insert([
            [   
                
                'description'=>'Modules',
                'icon' => 'fa fa-file',
                'created_at'=> Carbon::now(),
                'updated_at'=> Carbon::now()
            ],
            [
                'description'=>'Security',
                'icon' => 'fa fa-sun',
                'created_at'=> Carbon::now(),
                'updated_at'=> Carbon::now()
            ],

        ]);
        //
    }
}
