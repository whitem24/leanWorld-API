<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class PermissionsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('permissions')->insert(array (
            0 =>
            array (
            	'id' => 1,
                'description'=>'Permissions',
                'parent_id' => NULL,
                'menu_id' => 2,
                'created_at'=> Carbon::now(),
                'updated_at'=> Carbon::now(),
            ),
            1 =>
            array (
            	'id' => 2,
                'description'=>'Permissions-create',
                'parent_id' => 1,
                'menu_id' => 2,
                'created_at'=> Carbon::now(),
                'updated_at'=> Carbon::now(),
            ),
            2 =>
            array (
            	'id' => 3,
                'description'=>'Roles',
                'parent_id' => 1,
                'menu_id' => 2,
                'created_at'=> Carbon::now(),
                'updated_at'=> Carbon::now(),
            ),
            3 =>
            array (
            	'id' => 4,
                'description'=>'Permissions-edit',
                'parent_id' => 1,
                'menu_id' => 2,
                'created_at'=> Carbon::now(),
                'updated_at'=> Carbon::now(),
            ),
            4 =>
            array (
            	'id' => 5,
                'description'=>'Permissions-delete',
                'parent_id' => 1,
                'menu_id' => 2,
                'created_at'=> Carbon::now(),
                'updated_at'=> Carbon::now(),
            ),
        ));
    }
}
