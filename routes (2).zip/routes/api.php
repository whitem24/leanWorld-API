<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
// LeanWorld Routes external API

Route::get('/courses','CoursesController@index');

Route::get('/users','UsersController@index');

Route::get('/user/{userId}/profile','UsersController@show');

/* Route::get('/user/{userId}','UsersController@user'); */



Route::get('/courses-users/{titleId}','CoursesController@coursesUsers');

Route::get('/course/{titleId}','CoursesController@show');

//Internal Routes

Route::post('register', 'Internal\AuthController@register');
Route::post('login', 'Internal\AuthController@login');
Route::post('password/email', 'Internal\ForgotPasswordController@sendResetLinkEmail');
Route::post('password/reset', 'Internal\ResetPasswordController@reset');
Route::middleware('auth:api')->group(function() {

    Route::get('/actions/users','ActionsController@get_users');
    Route::post('/actions/send-emails','ActionsController@send_email');
    Route::get('/user/modality','PaymentModalityController@index');
    Route::get('/user/modality/{userId}/{courseId}','PaymentModalityController@get_user_course_modality');
    Route::post('/modality/courses','PaymentModalityController@assignModality');
    

    //Permissions Routes
    
    Route::get('/permissions','Internal\PermissionsController@index');
    Route::get('/permissions/create','Internal\PermissionsController@create');
    Route::post('/permissions','Internal\PermissionsController@store');
    Route::get('/permissions/{permissionId}/edit','Internal\PermissionsController@edit');
    Route::get('/permissions/{permissionId}','Internal\PermissionsController@show');
    Route::put('/permissions/{permissionId}','Internal\PermissionsController@update');
    Route::delete('/permissions/{permissionId}','Internal\PermissionsController@destroy');

    //Roles Routes
    
    Route::get('/roles','Internal\RolesController@index');
    Route::get('/roles/create','Internal\RolesController@create');
    Route::post('/roles','Internal\RolesController@store');
    Route::get('/roles/{permissionId}/edit','Internal\RolesController@edit');
    Route::get('/roles/{permissionId}','Internal\RolesController@show');
    Route::put('/roles/{permissionId}','Internal\RolesController@update');
    Route::delete('/roles/{permissionId}','Internal\RolesController@destroy');

    //Menus Routes
    
    Route::get('/menus','Internal\MenusController@index');
    Route::post('/menus','Internal\MenusController@store');
    Route::get('/menus/{menuId}/edit','Internal\MenusController@edit');
    Route::get('/menus/{menuId}','Internal\MenusController@show');
    Route::put('/menus/{menuId}','Internal\MenusController@update');
    Route::delete('/menus/{menuId}','Internal\MenusController@destroy');

    //Route::get('user/{userId}/detail', 'Internal\UserController@show');
});
